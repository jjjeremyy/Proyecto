/**
 * hooks/useWebVitals.ts
 * Hook para medir y reportar Web Vitals en el cliente.
 *
 * Métricas medidas:
 *  - LCP (Largest Contentful Paint): < 2.5s = bueno, < 4s = mejorable
 *  - FID (First Input Delay): < 100ms = bueno
 *  - CLS (Cumulative Layout Shift): < 0.1 = bueno
 *  - FCP (First Contentful Paint): < 1.8s = bueno
 *  - TTFB (Time to First Byte): < 800ms = bueno
 *  - INP (Interaction to Next Paint): < 200ms = bueno
 *
 * Uso en app/layout.tsx:
 *   import { WebVitalsReporter } from '@/hooks/useWebVitals';
 *   // Añadir <WebVitalsReporter /> al layout
 */

'use client';

import { useReportWebVitals } from 'next/web-vitals';

// ─── Umbrales de rendimiento ──────────────────────────────────────────────────
const THRESHOLDS = {
  LCP:  { good: 2500, poor: 4000 },
  FID:  { good: 100,  poor: 300  },
  CLS:  { good: 0.1,  poor: 0.25 },
  FCP:  { good: 1800, poor: 3000 },
  TTFB: { good: 800,  poor: 1800 },
  INP:  { good: 200,  poor: 500  },
} as const;

type MetricName = keyof typeof THRESHOLDS;

function getRating(name: string, value: number): 'good' | 'needs-improvement' | 'poor' {
  const threshold = THRESHOLDS[name as MetricName];
  if (!threshold) return 'good';
  if (value <= threshold.good) return 'good';
  if (value <= threshold.poor) return 'needs-improvement';
  return 'poor';
}

function formatValue(name: string, value: number): string {
  if (name === 'CLS') return value.toFixed(3);
  return `${Math.round(value)}ms`;
}

// ─── Componente de reporte ────────────────────────────────────────────────────
export function WebVitalsReporter() {
  useReportWebVitals((metric) => {
    const rating = getRating(metric.name, metric.value);
    const formattedValue = formatValue(metric.name, metric.value);
    const emoji = rating === 'good' ? '✅' : rating === 'needs-improvement' ? '⚠️' : '❌';

    // Log en consola del navegador (visible en DevTools)
    console.log(
      `%c[WebVitals] ${emoji} ${metric.name}: ${formattedValue} (${rating})`,
      `color: ${rating === 'good' ? 'green' : rating === 'needs-improvement' ? 'orange' : 'red'}`
    );

    // Enviar a analytics en producción
    if (process.env.NODE_ENV === 'production') {
      // Opción 1: Google Analytics 4
      if (typeof window !== 'undefined' && 'gtag' in window) {
        (window as Window & { gtag: Function }).gtag('event', metric.name, {
          value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
          event_category: 'Web Vitals',
          event_label: metric.id,
          non_interaction: true,
        });
      }

      // Opción 2: Endpoint propio
      // navigator.sendBeacon('/api/vitals', JSON.stringify({
      //   name: metric.name,
      //   value: metric.value,
      //   rating,
      //   id: metric.id,
      //   url: window.location.href,
      // }));
    }
  });

  return null; // Componente sin UI
}

// ─── Utilidad: medir tiempo de carga de página ───────────────────────────────
/**
 * Mide el tiempo total de carga de la página actual.
 * Llamar desde un useEffect en la página.
 */
export function measurePageLoad(pageName: string) {
  if (typeof window === 'undefined') return;

  window.addEventListener('load', () => {
    const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    if (!navigation) return;

    const metrics = {
      dns:          Math.round(navigation.domainLookupEnd - navigation.domainLookupStart),
      tcp:          Math.round(navigation.connectEnd - navigation.connectStart),
      ttfb:         Math.round(navigation.responseStart - navigation.requestStart),
      download:     Math.round(navigation.responseEnd - navigation.responseStart),
      domParsing:   Math.round(navigation.domContentLoadedEventStart - navigation.responseEnd),
      totalLoad:    Math.round(navigation.loadEventEnd - navigation.startTime),
    };

    console.table({
      Página: pageName,
      'DNS (ms)': metrics.dns,
      'TCP (ms)': metrics.tcp,
      'TTFB (ms)': metrics.ttfb,
      'Descarga (ms)': metrics.download,
      'DOM Parsing (ms)': metrics.domParsing,
      'Carga Total (ms)': metrics.totalLoad,
      'Objetivo < 500ms': metrics.totalLoad < 500 ? '✅ LOGRADO' : '❌ SUPERA OBJETIVO',
    });
  });
}
