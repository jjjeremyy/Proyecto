/**
 * types/article.ts
 * Tipos TypeScript para los artículos y entidades relacionadas.
 * Mantener sincronizados con el esquema de Supabase.
 */

// ─── Tipos base ───────────────────────────────────────────────────────────────

export interface Author {
  id: string;
  name: string;
  avatar_url: string | null;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
}

// ─── Artículo completo (para página de detalle) ───────────────────────────────
export interface Article {
  id: string;
  slug: string;
  title: string;
  content: string;          // Markdown o HTML del artículo completo
  summary: string;
  published_at: string;     // ISO 8601
  updated_at: string | null;
  cover_image_url: string | null;
  reading_time_minutes: number | null;
  author: Author | null;
  tags: Array<{ tag: Tag }>;
}

// ─── Artículo resumido (para listados) ───────────────────────────────────────
export interface ArticleListItem {
  id: string;
  slug: string;
  title: string;
  summary: string;
  published_at: string;
  cover_image_url: string | null;
  reading_time_minutes: number | null;
}

// ─── Solo slug (para generateStaticParams) ───────────────────────────────────
export interface ArticleSlug {
  slug: string;
}

// ─── Parámetros de paginación ─────────────────────────────────────────────────
export interface PaginationParams {
  page: number;
  limit: number;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

// ─── Payload del webhook de Supabase ─────────────────────────────────────────
export interface SupabaseWebhookPayload {
  type: 'INSERT' | 'UPDATE' | 'DELETE';
  table: string;
  schema: string;
  record: {
    id: string;
    slug: string;
    status: string;
    [key: string]: unknown;
  };
  old_record: {
    id: string;
    slug: string;
    status: string;
    [key: string]: unknown;
  } | null;
}
