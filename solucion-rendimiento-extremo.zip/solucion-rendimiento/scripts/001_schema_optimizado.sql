-- ─────────────────────────────────────────────────────────────────────────────
-- scripts/001_schema_optimizado.sql
-- Esquema optimizado de base de datos para la plataforma de artículos.
-- Ejecutar en el SQL Editor de Supabase o como migración.
--
-- Incluye:
--   - Tablas con tipos de datos correctos
--   - Índices para consultas frecuentes
--   - Row Level Security (RLS) para seguridad
--   - Triggers para updated_at automático
--   - Función para calcular tiempo de lectura
-- ─────────────────────────────────────────────────────────────────────────────

-- ─── Extensiones ─────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Para búsqueda de texto completo

-- ─── Tabla: authors ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS authors (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        TEXT NOT NULL,
  email       TEXT UNIQUE NOT NULL,
  avatar_url  TEXT,
  bio         TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Tabla: tags ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tags (
  id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name  TEXT NOT NULL UNIQUE,
  slug  TEXT NOT NULL UNIQUE
);

-- ─── Tabla: articles (principal) ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS articles (
  id                     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug                   TEXT NOT NULL UNIQUE,
  title                  TEXT NOT NULL,
  summary                TEXT NOT NULL,
  content                TEXT NOT NULL,          -- Markdown
  cover_image_url        TEXT,
  status                 TEXT NOT NULL DEFAULT 'draft'
                         CHECK (status IN ('draft', 'published', 'archived')),
  reading_time_minutes   INTEGER,
  page_views             BIGINT NOT NULL DEFAULT 0,
  author_id              UUID REFERENCES authors(id) ON DELETE SET NULL,
  published_at           TIMESTAMPTZ,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMPTZ
);

-- ─── Tabla: article_tags (relación N:N) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS article_tags (
  article_id  UUID NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
  tag_id      UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);

-- ─────────────────────────────────────────────────────────────────────────────
-- ÍNDICES CRÍTICOS PARA RENDIMIENTO
-- ─────────────────────────────────────────────────────────────────────────────

-- Índice primario: búsqueda por slug (consulta más frecuente)
-- Tipo B-Tree: O(log n) en lugar de O(n) para búsquedas exactas
CREATE UNIQUE INDEX IF NOT EXISTS idx_articles_slug
  ON articles (slug);

-- Índice para listados ordenados por fecha (con filtro de status)
-- Índice compuesto: evita un segundo filtro en memoria
CREATE INDEX IF NOT EXISTS idx_articles_status_published_at
  ON articles (status, published_at DESC)
  WHERE status = 'published';

-- Índice para búsquedas por autor
CREATE INDEX IF NOT EXISTS idx_articles_author_id
  ON articles (author_id);

-- Índice para artículos más vistos (ranking)
CREATE INDEX IF NOT EXISTS idx_articles_page_views
  ON articles (page_views DESC)
  WHERE status = 'published';

-- Índice para búsqueda de texto completo en título y resumen
CREATE INDEX IF NOT EXISTS idx_articles_fts
  ON articles USING GIN (
    to_tsvector('spanish', title || ' ' || summary)
  );

-- Índice trigram para búsqueda parcial (autocompletado)
CREATE INDEX IF NOT EXISTS idx_articles_title_trgm
  ON articles USING GIN (title gin_trgm_ops);

-- Índice para la tabla de relación article_tags
CREATE INDEX IF NOT EXISTS idx_article_tags_tag_id
  ON article_tags (tag_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- TRIGGERS
-- ─────────────────────────────────────────────────────────────────────────────

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger en articles
CREATE TRIGGER articles_updated_at
  BEFORE UPDATE ON articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Función para calcular tiempo de lectura (200 palabras/minuto)
CREATE OR REPLACE FUNCTION calculate_reading_time(content TEXT)
RETURNS INTEGER AS $$
DECLARE
  word_count INTEGER;
BEGIN
  word_count := array_length(string_to_array(trim(content), ' '), 1);
  RETURN GREATEST(1, ROUND(word_count / 200.0));
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Trigger para calcular tiempo de lectura al insertar/actualizar
CREATE OR REPLACE FUNCTION set_reading_time()
RETURNS TRIGGER AS $$
BEGIN
  NEW.reading_time_minutes = calculate_reading_time(NEW.content);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER articles_reading_time
  BEFORE INSERT OR UPDATE OF content ON articles
  FOR EACH ROW
  EXECUTE FUNCTION set_reading_time();

-- Función para establecer published_at al publicar
CREATE OR REPLACE FUNCTION set_published_at()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'published' AND OLD.status != 'published' THEN
    NEW.published_at = COALESCE(NEW.published_at, NOW());
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER articles_published_at
  BEFORE UPDATE ON articles
  FOR EACH ROW
  EXECUTE FUNCTION set_published_at();

-- ─────────────────────────────────────────────────────────────────────────────
-- ROW LEVEL SECURITY (RLS)
-- ─────────────────────────────────────────────────────────────────────────────

-- Activar RLS en todas las tablas
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE authors ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_tags ENABLE ROW LEVEL SECURITY;

-- Política: cualquiera puede leer artículos publicados
CREATE POLICY "articles_public_read" ON articles
  FOR SELECT
  USING (status = 'published');

-- Política: cualquiera puede leer autores y tags
CREATE POLICY "authors_public_read" ON authors
  FOR SELECT USING (true);

CREATE POLICY "tags_public_read" ON tags
  FOR SELECT USING (true);

CREATE POLICY "article_tags_public_read" ON article_tags
  FOR SELECT USING (true);

-- ─────────────────────────────────────────────────────────────────────────────
-- DATOS DE EJEMPLO (comentar en producción)
-- ─────────────────────────────────────────────────────────────────────────────

/*
INSERT INTO authors (name, email, avatar_url) VALUES
  ('Ana García', 'ana@ejemplo.com', 'https://ejemplo.com/avatar.jpg');

INSERT INTO tags (name, slug) VALUES
  ('Redes', 'redes'),
  ('Programación', 'programacion'),
  ('Sistemas Operativos', 'sistemas-operativos');

INSERT INTO articles (slug, title, summary, content, status, author_id) VALUES
  (
    'como-funciona-tcp-ip',
    '¿Cómo funciona TCP/IP?',
    'Una introducción completa al protocolo de comunicación más usado en Internet.',
    '## Introducción\n\nTCP/IP es el conjunto de protocolos...',
    'published',
    (SELECT id FROM authors WHERE email = 'ana@ejemplo.com')
  );
*/

-- ─────────────────────────────────────────────────────────────────────────────
-- VERIFICACIÓN DE ÍNDICES
-- Ejecutar para confirmar que los índices se crearon correctamente:
-- SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'articles';
-- ─────────────────────────────────────────────────────────────────────────────
