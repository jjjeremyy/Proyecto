# Guía de Arquitectura de Rendimiento Extremo: Next.js + Supabase

Esta guía detalla la implementación de una arquitectura web de alto rendimiento para una plataforma de artículos educativos. El objetivo principal es reducir los tiempos de carga a menos de 500 ms y eliminar por completo las consultas redundantes a la base de datos de Supabase, utilizando **Incremental Static Regeneration (ISR)**, **caché inteligente**, y **distribución global vía CDN**.

**Autor:** Manus AI

---

## 1. El Problema: Cuello de Botella en la Base de Datos

En la arquitectura tradicional de una Single Page Application (SPA) o Server-Side Rendering (SSR) puro, cada visitante que entra a leer un artículo desencadena una o más consultas a la base de datos (Supabase). Si un artículo se vuelve viral y recibe 1,000 visitas por minuto, Supabase recibirá 1,000 consultas idénticas por minuto, lo que provoca:

1. Aumento en la latencia (TTFB alto).
2. Consumo excesivo de recursos y posibles límites de cuota en Supabase.
3. Experiencia de usuario lenta (páginas en blanco mientras cargan los datos).

## 2. La Solución: ISR y Caché de Múltiples Capas

Para resolver esto, implementamos una arquitectura de **caché de tres capas** que garantiza que el 99% de las visitas se sirvan desde memoria estática, logrando tiempos de carga iniciales inferiores a 500 ms y visualización de contenido principal (LCP) en menos de 1 segundo.

### Capa 1: CDN Edge (Cloudflare / Vercel Edge Network)
La primera línea de defensa es la Content Delivery Network (CDN). Cuando un usuario solicita `/articulo/como-funciona-tcp-ip`, la CDN verifica si tiene una copia HTML de esa página. Si la tiene, la sirve en milisegundos desde un servidor geográficamente cercano al usuario, sin tocar tu servidor Node.js ni tu base de datos [1].

### Capa 2: Incremental Static Regeneration (ISR)
Next.js pre-genera las páginas de los artículos como HTML estático. Utilizamos ISR bajo demanda (`revalidatePath`). Cuando un autor publica o actualiza un artículo en Supabase, un **Database Webhook** envía una señal a nuestro endpoint `/api/revalidate`. Next.js regenera *solo ese artículo específico* en segundo plano, actualizando la CDN [2]. 

### Capa 3: Data Cache (`unstable_cache`)
Para las consultas a Supabase que ocurren en el servidor (ej. durante el build o cuando expira la caché de la CDN), envolvemos la llamada con `unstable_cache` de Next.js y le asignamos `tags` (ej. `['articles']`). Esto asegura que incluso si la página se regenera, si los datos no han cambiado, Next.js no golpea Supabase [3].

---

## 3. Optimización de Consultas a Supabase

Reducir las consultas a cero para visitantes recurrentes es vital, pero las consultas que sí se ejecutan deben ser ultrarrápidas.

### Selección de Campos y Paginación
Nunca hacemos `SELECT *`. En la página principal, donde listamos artículos, solo pedimos los metadatos necesarios:
```typescript
const { data } = await supabase
  .from('articles')
  .select('id, slug, title, summary, published_at, cover_image_url')
  .eq('status', 'published')
  .order('published_at', { ascending: false })
  .range(0, 9); // Paginación estricta
```

### Índices en PostgreSQL
El esquema de base de datos (ver `scripts/001_schema_optimizado.sql`) incluye índices B-Tree específicos para las columnas que usamos en los filtros y búsquedas, reduciendo el tiempo de búsqueda de O(n) a O(log n):
- `CREATE UNIQUE INDEX idx_articles_slug ON articles (slug);`
- `CREATE INDEX idx_articles_status_published_at ON articles (status, published_at DESC);`

---

## 4. Arquitectura de URLs Amigables (Slugs)

Reemplazamos los IDs complejos (UUIDs) por **slugs** legibles y optimizados para SEO:
- ❌ Mal: `/articulo/550e8400-e29b-41d4-a716-446655440000`
- ✅ Bien: `/articulo/como-funciona-tcp-ip`

El slug se genera automáticamente a partir del título (ver `lib/utils.ts`) y se almacena en una columna con un índice único en Supabase para búsquedas instantáneas.

---

## 5. Optimización de Recursos y Frontend (Core Web Vitals)

Para lograr un Largest Contentful Paint (LCP) menor a 1.2 segundos y un First Contentful Paint (FCP) menor a 500 ms, aplicamos las siguientes técnicas en el frontend [4]:

### Imágenes Modernas y Lazy Loading
Utilizamos el componente `next/image` configurado para generar formatos **WebP** y **AVIF**. 
- La imagen de portada del artículo (LCP element) lleva el atributo `priority={true}` para que el navegador la precargue inmediatamente.
- Todas las demás imágenes (dentro del contenido o en artículos relacionados) usan lazy loading por defecto.

### Carga Progresiva (Streaming y Suspense)
El HTML inicial se envía al navegador al instante. Componentes secundarios, como la sección de "Artículos Relacionados", se envuelven en un límite de `<Suspense>` de React. Esto permite mostrar el contenido principal mientras los componentes pesados o consultas secundarias se resuelven en segundo plano.

### Optimización de Fuentes y CSS
Evitamos las peticiones de red a Google Fonts. Utilizamos `next/font/google` para descargar la fuente "Inter" durante el build y servirla desde nuestro propio dominio. Usamos `display: swap` para asegurar que el texto sea visible inmediatamente con fuentes del sistema, eliminando el destello de texto invisible (FOIT).

---

## 6. Implementación Paso a Paso

Todo el código necesario ha sido generado en la carpeta `solucion-rendimiento`. A continuación, los pasos para desplegar esta arquitectura:

### Paso 1: Configurar Supabase
1. Ejecuta el script SQL ubicado en `scripts/001_schema_optimizado.sql` en el SQL Editor de tu proyecto Supabase. Esto creará las tablas, índices y triggers necesarios.
2. En el panel de Supabase, ve a **Database → Webhooks**.
3. Crea un nuevo webhook:
   - **Tabla:** `articles`
   - **Eventos:** Insert, Update, Delete
   - **URL:** `https://tu-dominio.com/api/revalidate`
   - **HTTP Headers:** Añade un header `x-webhook-secret` con un valor seguro (ej. un UUID aleatorio).

### Paso 2: Configurar el Proyecto Next.js
1. Copia el contenido de la carpeta generada a tu repositorio.
2. Copia `.env.example` a `.env.local` y rellena las variables:
   - `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` (de la configuración de Supabase).
   - `REVALIDATION_SECRET` (el mismo valor que pusiste en el webhook).
3. Instala las dependencias: `npm install`.

### Paso 3: Despliegue y CDN
Si despliegas en Vercel, la CDN y la invalidación de caché funcionan automáticamente.
Si usas Cloudflare frente a tu servidor, aplica las reglas detalladas en `config/cloudflare-cache-rules.md` para asegurar que Cloudflare cachee el HTML generado por Next.js y respete los headers `stale-while-revalidate`.

---

## 7. Medición y Monitoreo de Rendimiento

El código incluye herramientas integradas para medir el rendimiento:

1. **Logs de Servidor:** La función `measureTime` en `lib/utils.ts` envuelve las consultas a Supabase y registra los milisegundos exactos que toma cada consulta.
2. **Web Vitals en Cliente:** El hook `useWebVitals` (en `hooks/useWebVitals.ts`) captura métricas reales de los usuarios (LCP, FID, CLS) y las muestra en la consola o las envía a tu servicio de analíticas.

### Cómo probar el rendimiento final:
1. **DevTools Network Tab:** Abre tu web, abre las DevTools (F12), ve a Network y recarga. Selecciona el documento HTML principal. En la pestaña "Headers", busca `x-vercel-cache: HIT` o `cf-cache-status: HIT`. Si lo ves, la página se sirvió desde la CDN sin tocar tu servidor.
2. **PageSpeed Insights:** Ejecuta la URL de un artículo en [PageSpeed Insights](https://pagespeed.web.dev/). Deberías obtener una puntuación superior a 90 en la sección de rendimiento, con un LCP en verde.

---

## Referencias
[1] Cloudflare Documentation. *Cache Rules*. https://developers.cloudflare.com/cache/how-to/cache-rules/
[2] Next.js Documentation. *Incremental Static Regeneration (ISR)*. https://nextjs.org/docs/app/guides/incremental-static-regeneration
[3] Next.js Documentation. *Data Fetching, Caching, and Revalidating*. https://nextjs.org/docs/app/building-your-application/data-fetching/fetching-caching-and-revalidating
[4] Web.dev. *Largest Contentful Paint (LCP)*. https://web.dev/articles/lcp
