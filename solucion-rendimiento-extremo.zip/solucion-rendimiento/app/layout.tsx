/**
 * app/layout.tsx
 * Layout raíz de la aplicación.
 *
 * Optimizaciones incluidas:
 *  - Fuente del sistema (Inter via next/font) cargada en build time.
 *  - Metadatos base para SEO y Open Graph.
 *  - Web Vitals reporting.
 *  - Preconnect a Supabase para reducir latencia de primera consulta.
 *  - Viewport y theme-color para móviles.
 */

import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

// ─── Fuente optimizada ────────────────────────────────────────────────────────
// next/font descarga la fuente en build time y la sirve desde el mismo dominio.
// Elimina el layout shift (CLS) y las peticiones externas a Google Fonts.
const inter = Inter({
  subsets: ['latin'],
  display: 'swap',          // Muestra texto con fuente del sistema mientras carga
  variable: '--font-inter', // Variable CSS para uso en Tailwind
  preload: true,
  fallback: [
    'system-ui',
    '-apple-system',
    'BlinkMacSystemFont',
    'Segoe UI',
    'sans-serif',
  ],
});

// ─── Metadatos base ───────────────────────────────────────────────────────────
export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? 'https://tu-dominio.com'
  ),
  title: {
    default: 'Artículos de Informática',
    template: '%s | Artículos de Informática',
  },
  description:
    'Plataforma de artículos técnicos sobre informática para estudiantes y profesionales.',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
};

// ─── Viewport ─────────────────────────────────────────────────────────────────
export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#ffffff',
};

// ─── Layout ───────────────────────────────────────────────────────────────────
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es" className={inter.variable}>
      <head>
        {/* Preconnect a Supabase para reducir latencia de primera consulta */}
        <link
          rel="preconnect"
          href={process.env.NEXT_PUBLIC_SUPABASE_URL}
          crossOrigin="anonymous"
        />
        {/* DNS prefetch como fallback */}
        <link
          rel="dns-prefetch"
          href={process.env.NEXT_PUBLIC_SUPABASE_URL}
        />
      </head>
      <body className="font-sans antialiased bg-gray-50 text-gray-900 min-h-screen">
        {/* Barra de navegación */}
        <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
          <div className="container mx-auto px-4 max-w-6xl h-14 flex items-center justify-between">
            <a href="/" className="font-bold text-lg text-gray-900 hover:text-blue-600">
              Informática
            </a>
            <div className="flex gap-4 text-sm text-gray-600">
              <a href="/" className="hover:text-blue-600 transition-colors">Artículos</a>
              <a href="/sobre-nosotros" className="hover:text-blue-600 transition-colors">Acerca de</a>
            </div>
          </div>
        </nav>

        {/* Contenido principal */}
        {children}

        {/* Footer */}
        <footer className="mt-16 border-t border-gray-200 py-8 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} Artículos de Informática. Todos los derechos reservados.</p>
        </footer>
      </body>
    </html>
  );
}
