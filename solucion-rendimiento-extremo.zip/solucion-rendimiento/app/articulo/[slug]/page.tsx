/**
 * app/articulo/[slug]/page.tsx
 * Página de artículo individual con ISR y metadatos SEO dinámicos.
 *
 * Rendimiento objetivo:
 *  - TTFB: < 50 ms (HTML servido desde CDN edge)
 *  - LCP:  < 1.2 s (imagen de portada con priority preload)
 *  - FCP:  < 500 ms (HTML estático pre-generado)
 *  - CLS:  0 (dimensiones de imagen explícitas)
 */

import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import Image from 'next/image';
import type { Metadata } from 'next';

import { getCachedArticleBySlug, getCachedAllSlugs, getCachedRelatedArticles } from '@/lib/cache';
import RelatedArticles from '@/components/article/RelatedArticles';
import ArticleCardSkeleton from '@/components/ui/ArticleCardSkeleton';
import ArticleContent from '@/components/article/ArticleContent';
import { formatDate, formatReadingTime } from '@/lib/utils';

// ─── Configuración de ISR ─────────────────────────────────────────────────────
// Revalidación máxima: 24 horas (fallback si el webhook no se dispara).
// En la práctica, el webhook invalida on-demand al publicar/editar.
export const revalidate = 86400;

// Páginas no pre-generadas → se generan on-demand y se cachean.
// false = 404 para slugs desconocidos (más seguro).
export const dynamicParams = true;

// ─── Pre-generación en build time ────────────────────────────────────────────
/**
 * Genera estáticamente los artículos más recientes durante el build.
 * El resto se genera on-demand en la primera visita.
 */
export async function generateStaticParams() {
  const slugs = await getCachedAllSlugs();
  return slugs.map(({ slug }) => ({ slug }));
}

// ─── Metadatos SEO dinámicos ──────────────────────────────────────────────────
export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const article = await getCachedArticleBySlug(params.slug);

  if (!article) {
    return { title: 'Artículo no encontrado' };
  }

  const ogImage = article.cover_image_url
    ? [{ url: article.cover_image_url, width: 1200, height: 630, alt: article.title }]
    : [];

  return {
    title: `${article.title} | Informática`,
    description: article.summary,
    openGraph: {
      title: article.title,
      description: article.summary,
      type: 'article',
      publishedTime: article.published_at,
      modifiedTime: article.updated_at ?? undefined,
      authors: article.author ? [article.author.name] : [],
      images: ogImage,
    },
    twitter: {
      card: 'summary_large_image',
      title: article.title,
      description: article.summary,
      images: ogImage.map((img) => img.url),
    },
    alternates: {
      canonical: `/articulo/${params.slug}`,
    },
  };
}

// ─── Componente de artículos relacionados (carga diferida) ───────────────────
async function RelatedSection({
  currentSlug,
  tagIds,
}: {
  currentSlug: string;
  tagIds: string[];
}) {
  const related = await getCachedRelatedArticles(currentSlug, tagIds);
  if (!related.length) return null;
  return <RelatedArticles articles={related} />;
}

// ─── Página principal ─────────────────────────────────────────────────────────
export default async function ArticlePage({
  params,
}: {
  params: { slug: string };
}) {
  const article = await getCachedArticleBySlug(params.slug);

  if (!article) return notFound();

  const tagIds = article.tags.map((t) => t.tag.id);
  const publishedDate = formatDate(article.published_at);
  const readingTime = formatReadingTime(article.reading_time_minutes);

  return (
    <>
      {/* JSON-LD para SEO estructurado */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'TechArticle',
            headline: article.title,
            description: article.summary,
            datePublished: article.published_at,
            dateModified: article.updated_at ?? article.published_at,
            author: article.author
              ? { '@type': 'Person', name: article.author.name }
              : undefined,
            image: article.cover_image_url,
          }),
        }}
      />

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        {/* ── Cabecera del artículo ── */}
        <header className="mb-8">
          {/* Tags */}
          {article.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {article.tags.map(({ tag }) => (
                <span
                  key={tag.id}
                  className="text-xs font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded-full"
                >
                  {tag.name}
                </span>
              ))}
            </div>
          )}

          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-gray-900 leading-tight">
            {article.title}
          </h1>

          <p className="mt-3 text-lg text-gray-600">{article.summary}</p>

          {/* Meta: autor, fecha, tiempo de lectura */}
          <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
            {article.author && (
              <div className="flex items-center gap-2">
                {article.author.avatar_url && (
                  <Image
                    src={article.author.avatar_url}
                    alt={article.author.name}
                    width={28}
                    height={28}
                    className="rounded-full"
                  />
                )}
                <span>{article.author.name}</span>
              </div>
            )}
            <time dateTime={article.published_at}>{publishedDate}</time>
            {readingTime && <span>{readingTime}</span>}
          </div>
        </header>

        {/* ── Imagen de portada (LCP element) ── */}
        {article.cover_image_url && (
          <div className="relative w-full aspect-video mb-8 rounded-xl overflow-hidden">
            <Image
              src={article.cover_image_url}
              alt={`Imagen de portada: ${article.title}`}
              fill
              sizes="(max-width: 768px) 100vw, 768px"
              className="object-cover"
              priority // Preload: este es el LCP element
              quality={85}
            />
          </div>
        )}

        {/* ── Contenido del artículo ── */}
        <ArticleContent content={article.content} />

        {/* ── Artículos relacionados (carga diferida con Suspense) ── */}
        <section className="mt-16 border-t pt-8">
          <h2 className="text-xl font-semibold mb-6 text-gray-800">
            Artículos relacionados
          </h2>
          <Suspense
            fallback={
              <div className="grid gap-4 sm:grid-cols-3">
                {[1, 2, 3].map((i) => (
                  <ArticleCardSkeleton key={i} />
                ))}
              </div>
            }
          >
            <RelatedSection currentSlug={params.slug} tagIds={tagIds} />
          </Suspense>
        </section>
      </main>
    </>
  );
}
