/**
 * app/page.tsx
 * Página principal: listado de artículos con ISR (revalidación cada 1 hora).
 *
 * Flujo de caché:
 *  1. Build time → HTML estático generado con los 10 artículos más recientes.
 *  2. Visitas recurrentes → HTML servido directamente desde CDN (0 ms DB).
 *  3. Cada hora → Next.js regenera la página en background si hay nueva visita.
 *  4. Al publicar artículo → webhook invalida el tag 'articles' → regeneración inmediata.
 */

import { Suspense } from 'react';
import { getCachedArticleList } from '@/lib/cache';
import ArticleCard from '@/components/article/ArticleCard';
import ArticleCardSkeleton from '@/components/ui/ArticleCardSkeleton';
import type { Metadata } from 'next';

// ─── Metadatos SEO ────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  title: 'Artículos de Informática | Tu Plataforma de Aprendizaje',
  description:
    'Aprende informática con artículos técnicos sobre redes, programación, sistemas operativos y más. Contenido actualizado para estudiantes y profesionales.',
  openGraph: {
    type: 'website',
    locale: 'es_ES',
  },
};

// ─── Configuración de ISR ─────────────────────────────────────────────────────
// Revalidación basada en tiempo: fallback si el webhook no se dispara.
export const revalidate = 3600; // 1 hora

// ─── Componente de listado (async) ────────────────────────────────────────────
async function ArticleList({ page }: { page: number }) {
  const articles = await getCachedArticleList(page, 10);

  if (!articles.length) {
    return (
      <p className="text-center text-gray-500 py-12">
        No hay artículos publicados todavía.
      </p>
    );
  }

  return (
    <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {articles.map((article) => (
        <li key={article.id}>
          <ArticleCard article={article} />
        </li>
      ))}
    </ul>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────────
export default function HomePage({
  searchParams,
}: {
  searchParams: { page?: string };
}) {
  const page = Math.max(0, Number(searchParams.page ?? 0));

  return (
    <main className="container mx-auto px-4 py-8 max-w-6xl">
      <header className="mb-10">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900">
          Artículos de Informática
        </h1>
        <p className="mt-2 text-lg text-gray-600">
          Recursos técnicos para estudiantes y profesionales del sector.
        </p>
      </header>

      {/* Suspense permite mostrar el skeleton mientras se carga el listado */}
      <Suspense
        fallback={
          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <li key={i}>
                <ArticleCardSkeleton />
              </li>
            ))}
          </ul>
        }
      >
        <ArticleList page={page} />
      </Suspense>
    </main>
  );
}
