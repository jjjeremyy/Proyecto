/**
 * app/sitemap.ts
 * Generador de sitemap XML dinámico para SEO.
 * Se regenera automáticamente con ISR (revalidación semanal).
 *
 * Accesible en: https://tu-dominio.com/sitemap.xml
 */

import type { MetadataRoute } from 'next';
import { getCachedAllSlugs } from '@/lib/cache';

export const revalidate = 604800; // 1 semana

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://tu-dominio.com';

  // Obtener todos los slugs publicados
  const slugs = await getCachedAllSlugs();

  // Páginas estáticas
  const staticPages: MetadataRoute.Sitemap = [
    {
      url: siteUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
    {
      url: `${siteUrl}/sobre-nosotros`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.5,
    },
  ];

  // Páginas de artículos
  const articlePages: MetadataRoute.Sitemap = slugs.map(({ slug }) => ({
    url: `${siteUrl}/articulo/${slug}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }));

  return [...staticPages, ...articlePages];
}
