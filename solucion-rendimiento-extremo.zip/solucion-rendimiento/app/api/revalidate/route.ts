/**
 * app/api/revalidate/route.ts
 * Endpoint de revalidación on-demand para ISR.
 *
 * Este endpoint es invocado por un webhook de Supabase (Database Webhooks)
 * cada vez que se inserta, actualiza o elimina un artículo en la tabla 'articles'.
 *
 * Flujo completo:
 *  1. Autor publica/edita artículo en el CMS (Supabase).
 *  2. Supabase dispara un Database Webhook → POST a /api/revalidate.
 *  3. Este handler valida el secreto y llama a revalidatePath/revalidateTag.
 *  4. Next.js invalida la caché del artículo y del listado.
 *  5. La próxima visita al artículo genera el HTML fresco desde Supabase.
 *  6. Todas las visitas posteriores sirven el nuevo HTML desde CDN.
 *
 * Configuración del webhook en Supabase:
 *  - Tabla: articles
 *  - Eventos: INSERT, UPDATE, DELETE
 *  - URL: https://tu-dominio.com/api/revalidate
 *  - Headers: { "x-webhook-secret": "<REVALIDATION_SECRET>" }
 */

import { revalidatePath, revalidateTag } from 'next/cache';
import { NextRequest, NextResponse } from 'next/server';
import type { SupabaseWebhookPayload } from '@/types/article';
import { CACHE_TAGS } from '@/lib/cache';

// ─── Constantes ───────────────────────────────────────────────────────────────
const REVALIDATION_SECRET = process.env.REVALIDATION_SECRET;

// ─── Handler POST ─────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  const startTime = Date.now();

  // 1. Verificar secreto de seguridad
  const secret = request.headers.get('x-webhook-secret');
  if (!REVALIDATION_SECRET || secret !== REVALIDATION_SECRET) {
    console.warn('[Revalidate] Intento no autorizado desde:', request.ip);
    return NextResponse.json(
      { message: 'Unauthorized: invalid secret' },
      { status: 401 }
    );
  }

  // 2. Parsear el payload del webhook
  let payload: SupabaseWebhookPayload;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json(
      { message: 'Bad Request: invalid JSON body' },
      { status: 400 }
    );
  }

  const { type, table, record, old_record } = payload;

  // 3. Solo procesar la tabla 'articles'
  if (table !== 'articles') {
    return NextResponse.json({ message: 'Ignored: not articles table' });
  }

  // 4. Determinar el slug afectado
  // En UPDATE, usar el slug del registro antiguo por si cambió
  const affectedSlug = record?.slug ?? old_record?.slug;

  if (!affectedSlug) {
    console.error('[Revalidate] Payload sin slug:', payload);
    return NextResponse.json(
      { message: 'Bad Request: missing slug in payload' },
      { status: 400 }
    );
  }

  console.log(`[Revalidate] Evento: ${type} | Slug: "${affectedSlug}"`);

  // 5. Invalidar caché del artículo específico
  revalidatePath(`/articulo/${affectedSlug}`);

  // 6. Si el slug cambió en un UPDATE, invalidar también el nuevo slug
  if (type === 'UPDATE' && record.slug !== old_record?.slug) {
    revalidatePath(`/articulo/${record.slug}`);
    console.log(`[Revalidate] Slug cambiado: "${old_record?.slug}" → "${record.slug}"`);
  }

  // 7. Invalidar el listado de artículos (home y paginación)
  revalidatePath('/');
  revalidatePath('/articulos');

  // 8. Invalidar por tag (invalida todas las consultas etiquetadas con 'articles')
  revalidateTag(CACHE_TAGS.articles);
  revalidateTag(CACHE_TAGS.sitemap);

  const elapsed = Date.now() - startTime;
  console.log(`[Revalidate] Completado en ${elapsed}ms`);

  return NextResponse.json({
    revalidated: true,
    slug: affectedSlug,
    event: type,
    elapsed_ms: elapsed,
    timestamp: new Date().toISOString(),
  });
}

// ─── Handler GET (health check) ───────────────────────────────────────────────
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Revalidation endpoint is active',
    timestamp: new Date().toISOString(),
  });
}
