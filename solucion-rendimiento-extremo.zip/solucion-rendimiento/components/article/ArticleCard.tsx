/**
 * components/article/ArticleCard.tsx
 * Tarjeta de artículo para el listado principal.
 *
 * Optimizaciones:
 *  - Imagen con lazy loading (por defecto en next/image).
 *  - Dimensiones explícitas para evitar CLS.
 *  - Link prefetch automático de Next.js en hover.
 *  - Renderizado en servidor (Server Component).
 */

import Image from 'next/image';
import Link from 'next/link';
import type { ArticleListItem } from '@/types/article';
import { formatDate, formatReadingTime } from '@/lib/utils';

interface ArticleCardProps {
  article: ArticleListItem;
}

export default function ArticleCard({ article }: ArticleCardProps) {
  const publishedDate = formatDate(article.published_at);
  const readingTime = formatReadingTime(article.reading_time_minutes);

  return (
    <article className="group flex flex-col h-full bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200">
      {/* Imagen de portada con lazy loading */}
      <Link
        href={`/articulo/${article.slug}`}
        className="block relative aspect-video overflow-hidden bg-gray-100"
        tabIndex={-1}
        aria-hidden="true"
      >
        {article.cover_image_url ? (
          <Image
            src={article.cover_image_url}
            alt={`Portada: ${article.title}`}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            className="object-cover group-hover:scale-105 transition-transform duration-300"
            // Sin priority: lazy loading por defecto para imágenes fuera del viewport
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-indigo-200 flex items-center justify-center">
            <span className="text-4xl text-blue-300">📄</span>
          </div>
        )}
      </Link>

      {/* Contenido de la tarjeta */}
      <div className="flex flex-col flex-1 p-5">
        <h2 className="text-base font-semibold text-gray-900 leading-snug mb-2 line-clamp-2">
          <Link
            href={`/articulo/${article.slug}`}
            className="hover:text-blue-600 transition-colors"
          >
            {article.title}
          </Link>
        </h2>

        <p className="text-sm text-gray-600 line-clamp-3 flex-1 mb-4">
          {article.summary}
        </p>

        {/* Meta: fecha y tiempo de lectura */}
        <footer className="flex items-center justify-between text-xs text-gray-400 mt-auto">
          <time dateTime={article.published_at}>{publishedDate}</time>
          {readingTime && <span>{readingTime}</span>}
        </footer>
      </div>
    </article>
  );
}
