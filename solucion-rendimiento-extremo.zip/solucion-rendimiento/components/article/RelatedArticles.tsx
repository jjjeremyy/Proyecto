/**
 * components/article/RelatedArticles.tsx
 * Sección de artículos relacionados.
 * Se carga de forma diferida con Suspense para no bloquear el LCP.
 */

import ArticleCard from './ArticleCard';
import type { ArticleListItem } from '@/types/article';

interface RelatedArticlesProps {
  articles: ArticleListItem[];
}

export default function RelatedArticles({ articles }: RelatedArticlesProps) {
  if (!articles.length) return null;

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {articles.map((article) => (
        <ArticleCard key={article.id} article={article} />
      ))}
    </div>
  );
}
