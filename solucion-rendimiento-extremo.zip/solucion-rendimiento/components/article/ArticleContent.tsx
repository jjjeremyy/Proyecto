/**
 * components/article/ArticleContent.tsx
 * Renderizador del contenido del artículo (Markdown o HTML).
 *
 * Si el contenido está en Markdown, se convierte a HTML en el servidor
 * usando 'marked' o 'remark', evitando procesamiento en el cliente.
 * Si ya es HTML, se sanitiza con DOMPurify (versión servidor).
 *
 * Instalación de dependencias:
 *   npm install marked highlight.js
 *   npm install --save-dev @types/marked
 */

// Server Component: el procesamiento ocurre en el servidor, no en el cliente.
import { marked } from 'marked';
import { markedHighlight } from 'marked-highlight';
import hljs from 'highlight.js';

// Configurar resaltado de código
marked.use(
  markedHighlight({
    langPrefix: 'hljs language-',
    highlight(code, lang) {
      const language = hljs.getLanguage(lang) ? lang : 'plaintext';
      return hljs.highlight(code, { language }).value;
    },
  })
);

// Configuración de marked para seguridad y rendimiento
marked.setOptions({
  gfm: true,    // GitHub Flavored Markdown
  breaks: true, // Saltos de línea como <br>
});

interface ArticleContentProps {
  content: string;
}

export default function ArticleContent({ content }: ArticleContentProps) {
  // Convertir Markdown a HTML en el servidor
  const htmlContent = marked.parse(content) as string;

  return (
    <div
      className="prose prose-gray max-w-none
        prose-headings:font-bold prose-headings:tracking-tight
        prose-h2:text-2xl prose-h2:mt-10 prose-h2:mb-4
        prose-h3:text-xl prose-h3:mt-8 prose-h3:mb-3
        prose-p:leading-relaxed prose-p:text-gray-700
        prose-a:text-blue-600 prose-a:no-underline hover:prose-a:underline
        prose-code:bg-gray-100 prose-code:px-1 prose-code:rounded prose-code:text-sm
        prose-pre:bg-gray-900 prose-pre:rounded-xl prose-pre:overflow-x-auto
        prose-blockquote:border-l-blue-500 prose-blockquote:bg-blue-50 prose-blockquote:py-1
        prose-img:rounded-xl prose-img:shadow-sm"
      dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
  );
}
