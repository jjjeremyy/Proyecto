/**
 * components/ui/ArticleCardSkeleton.tsx
 * Skeleton de carga para tarjetas de artículos.
 * Se muestra mientras Suspense espera la carga de datos.
 * Evita el CLS al mantener las mismas dimensiones que ArticleCard.
 */

export default function ArticleCardSkeleton() {
  return (
    <div
      className="flex flex-col h-full bg-white rounded-xl border border-gray-200 overflow-hidden animate-pulse"
      aria-hidden="true"
    >
      {/* Imagen placeholder */}
      <div className="aspect-video bg-gray-200" />

      {/* Contenido placeholder */}
      <div className="flex flex-col flex-1 p-5 gap-3">
        {/* Título */}
        <div className="h-4 bg-gray-200 rounded w-3/4" />
        <div className="h-4 bg-gray-200 rounded w-1/2" />

        {/* Resumen */}
        <div className="space-y-2 flex-1">
          <div className="h-3 bg-gray-100 rounded w-full" />
          <div className="h-3 bg-gray-100 rounded w-full" />
          <div className="h-3 bg-gray-100 rounded w-2/3" />
        </div>

        {/* Meta */}
        <div className="flex justify-between mt-auto">
          <div className="h-3 bg-gray-100 rounded w-20" />
          <div className="h-3 bg-gray-100 rounded w-16" />
        </div>
      </div>
    </div>
  );
}
