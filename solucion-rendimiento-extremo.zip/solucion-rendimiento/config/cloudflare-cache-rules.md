# Configuración de Cloudflare para CDN Global

## Reglas de Caché (Cache Rules)

Estas reglas se configuran en el panel de Cloudflare:
**Caching → Cache Rules → Create rule**

---

### Regla 1: Assets Estáticos (JS, CSS, Fuentes)

**Nombre:** `Static Assets - Aggressive Cache`

**Condición:**
```
(http.request.uri.path matches "^/_next/static/.*")
OR
(http.request.uri.path matches ".*\.(woff2|woff|ttf|eot)$")
```

**Configuración de caché:**
- **Cache Status:** Eligible for cache
- **Edge TTL:** Ignore cache-control header, use 1 year (31536000 seconds)
- **Browser TTL:** Respect existing headers

---

### Regla 2: Imágenes

**Nombre:** `Images - Long Cache`

**Condición:**
```
(http.request.uri.path matches ".*\.(jpg|jpeg|png|gif|webp|avif|svg|ico)$")
OR
(http.request.uri.path matches "^/_next/image.*")
```

**Configuración de caché:**
- **Cache Status:** Eligible for cache
- **Edge TTL:** 30 days (2592000 seconds)
- **Browser TTL:** 7 days

---

### Regla 3: Páginas de Artículos (HTML)

**Nombre:** `Article Pages - ISR Cache`

**Condición:**
```
(http.request.uri.path matches "^/articulo/.*")
AND
(http.request.method eq "GET")
```

**Configuración de caché:**
- **Cache Status:** Eligible for cache
- **Edge TTL:** Respect origin Cache-Control header (s-maxage=3600)
- **Browser TTL:** Respect existing headers
- **Stale-While-Revalidate:** Enabled

---

### Regla 4: Página Principal

**Nombre:** `Homepage - ISR Cache`

**Condición:**
```
(http.request.uri.path eq "/")
AND
(http.request.method eq "GET")
```

**Configuración de caché:**
- **Cache Status:** Eligible for cache
- **Edge TTL:** 1 hour (3600 seconds)

---

### Regla 5: Endpoint de Revalidación (Sin Caché)

**Nombre:** `Revalidation API - No Cache`

**Condición:**
```
(http.request.uri.path eq "/api/revalidate")
```

**Configuración de caché:**
- **Cache Status:** Bypass

---

## Configuración de Polish (Optimización de Imágenes)

En **Speed → Optimization → Polish**:
- **Polish:** Lossless o Lossy (según preferencia)
- **WebP:** Enabled (convierte automáticamente a WebP para navegadores compatibles)

---

## Configuración de Minify

En **Speed → Optimization → Auto Minify**:
- ✅ JavaScript
- ✅ CSS
- ✅ HTML

---

## Configuración de HTTP/3 y QUIC

En **Network**:
- ✅ HTTP/3 (with QUIC) — Reduce latencia en conexiones móviles
- ✅ 0-RTT Connection Resumption

---

## Verificar que el Caché Funciona

Después de desplegar, verificar los headers de respuesta:

```bash
curl -I https://tu-dominio.com/articulo/nombre-del-articulo

# Respuesta esperada:
# cache-control: public, s-maxage=3600, stale-while-revalidate=86400
# cf-cache-status: HIT          ← Servido desde Cloudflare CDN
# age: 1234                     ← Segundos desde que se cacheó
# x-vercel-cache: HIT           ← Si usas Vercel como origen
```

**cf-cache-status posibles valores:**
| Valor | Significado |
|-------|-------------|
| `HIT` | Servido desde CDN (0 consultas a DB) |
| `MISS` | Primera visita, generado en servidor |
| `STALE` | Sirviendo versión antigua mientras regenera |
| `BYPASS` | Caché desactivado para esta URL |
| `EXPIRED` | Caché expirado, regenerando |
