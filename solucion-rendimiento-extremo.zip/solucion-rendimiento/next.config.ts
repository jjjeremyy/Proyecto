/**
 * next.config.ts
 * Configuración de Next.js optimizada para rendimiento extremo.
 *
 * Optimizaciones activadas:
 *  - Imágenes: WebP/AVIF automático, tamaños responsivos, caché agresiva.
 *  - Headers: Cache-Control, seguridad y preload de recursos críticos.
 *  - Compresión: Gzip/Brotli para todos los assets.
 *  - Bundle: Análisis de tamaño y eliminación de código muerto.
 *  - Logs de caché en desarrollo para depuración.
 */

import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // ─── Optimización de imágenes ────────────────────────────────────────────
  images: {
    // Formatos modernos: AVIF (mejor compresión) y WebP (mejor compatibilidad)
    formats: ['image/avif', 'image/webp'],

    // Tamaños de dispositivo para srcset responsivo
    deviceSizes: [640, 750, 828, 1080, 1200, 1920],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],

    // Caché de imágenes optimizadas: 30 días
    minimumCacheTTL: 60 * 60 * 24 * 30,

    // Dominios permitidos para imágenes externas (Supabase Storage)
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
      {
        protocol: 'https',
        hostname: '*.supabase.in',
        pathname: '/storage/v1/object/public/**',
      },
    ],
  },

  // ─── Compresión ──────────────────────────────────────────────────────────
  compress: true, // Gzip/Brotli para respuestas HTTP

  // ─── Headers de caché y seguridad ────────────────────────────────────────
  async headers() {
    return [
      // Assets estáticos: caché agresiva (1 año, inmutable)
      {
        source: '/_next/static/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
      // Imágenes optimizadas: caché 30 días
      {
        source: '/_next/image/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=2592000, stale-while-revalidate=86400',
          },
        ],
      },
      // Páginas de artículos: caché CDN 1 hora, stale-while-revalidate 24 horas
      {
        source: '/articulo/:slug*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, s-maxage=3600, stale-while-revalidate=86400',
          },
          // Seguridad
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
      // Página principal: caché CDN 1 hora
      {
        source: '/',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, s-maxage=3600, stale-while-revalidate=86400',
          },
        ],
      },
      // Endpoint de revalidación: sin caché
      {
        source: '/api/revalidate',
        headers: [
          { key: 'Cache-Control', value: 'no-store' },
        ],
      },
    ];
  },

  // ─── Redirecciones ────────────────────────────────────────────────────────
  async redirects() {
    return [
      // Redirigir URLs antiguas con ID a slugs
      // { source: '/post/:id', destination: '/articulo/:id', permanent: true },
    ];
  },

  // ─── Logs de caché (solo en desarrollo) ──────────────────────────────────
  logging: {
    fetches: {
      fullUrl: process.env.NODE_ENV === 'development',
    },
  },

  // ─── Experimental ────────────────────────────────────────────────────────
  experimental: {
    // Optimizar importaciones de paquetes grandes
    optimizePackageImports: ['highlight.js', 'marked'],
    // Partial Prerendering (PPR): combina estático y dinámico en la misma página
    // ppr: true, // Habilitar cuando esté disponible en producción
  },

  // ─── Variables de entorno públicas ───────────────────────────────────────
  env: {
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL ?? '',
  },
};

export default nextConfig;
