/**
 * lib/supabase.ts
 * Cliente Supabase optimizado para SSR/SSG con Next.js App Router.
 * Utiliza el cliente de solo lectura para consultas de datos públicos
 * y el cliente completo para operaciones autenticadas (admin).
 */

import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/database';

// ─── Variables de entorno ────────────────────────────────────────────────────
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error(
    '[Supabase] Faltan variables de entorno: NEXT_PUBLIC_SUPABASE_URL o NEXT_PUBLIC_SUPABASE_ANON_KEY'
  );
}

// ─── Cliente público (lectura, lado del servidor) ────────────────────────────
// Se usa para fetch de datos en Server Components.
// La clave anon tiene Row Level Security (RLS) activada.
export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: false, // No persistir sesión en el servidor
    autoRefreshToken: false,
  },
});

// ─── Cliente administrador (solo en el servidor) ─────────────────────────────
// Usar ÚNICAMENTE en Server Actions, Route Handlers o scripts de build.
// NUNCA exponer en el cliente.
export const supabaseAdmin = createClient<Database>(
  SUPABASE_URL,
  SUPABASE_SERVICE_ROLE_KEY,
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  }
);
