/**
 * lib/utils.ts
 * Funciones utilitarias: formato de fechas, tiempos de lectura,
 * medición de rendimiento y generación de slugs.
 */

// ─── Formato de fechas ────────────────────────────────────────────────────────
/**
 * Formatea una fecha ISO 8601 en formato legible en español.
 * Ejemplo: "2024-03-15T10:30:00Z" → "15 de marzo de 2024"
 */
export function formatDate(isoDate: string): string {
  return new Intl.DateTimeFormat('es-ES', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(new Date(isoDate));
}

/**
 * Formatea el tiempo de lectura estimado.
 * Ejemplo: 5 → "5 min de lectura"
 */
export function formatReadingTime(minutes: number | null): string | null {
  if (!minutes) return null;
  return `${minutes} min de lectura`;
}

// ─── Generación de slugs ──────────────────────────────────────────────────────
/**
 * Convierte un título en un slug URL-amigable.
 * Ejemplo: "¿Cómo funciona TCP/IP?" → "como-funciona-tcp-ip"
 */
export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .normalize('NFD')                        // Descomponer caracteres acentuados
    .replace(/[\u0300-\u036f]/g, '')         // Eliminar diacríticos
    .replace(/[¿¡]/g, '')                    // Eliminar signos de interrogación/exclamación
    .replace(/[^a-z0-9\s-]/g, '')           // Solo letras, números, espacios y guiones
    .trim()
    .replace(/\s+/g, '-')                    // Espacios → guiones
    .replace(/-+/g, '-');                    // Múltiples guiones → uno solo
}

// ─── Medición de rendimiento ──────────────────────────────────────────────────
/**
 * Mide el tiempo de ejecución de una función asíncrona y lo registra en consola.
 * Útil para medir el tiempo real de consultas a Supabase.
 *
 * @param label   Etiqueta descriptiva para el log
 * @param fn      Función asíncrona a medir
 * @returns       El resultado de la función
 *
 * @example
 * const articles = await measureTime('getCachedArticleList', () => getCachedArticleList(0, 10));
 */
export async function measureTime<T>(
  label: string,
  fn: () => Promise<T>
): Promise<T> {
  const start = performance.now();
  try {
    const result = await fn();
    const elapsed = (performance.now() - start).toFixed(2);
    console.log(`[Perf] ${label}: ${elapsed}ms`);
    return result;
  } catch (error) {
    const elapsed = (performance.now() - start).toFixed(2);
    console.error(`[Perf] ${label} FAILED after ${elapsed}ms:`, error);
    throw error;
  }
}

/**
 * Registra las métricas de Web Vitals en el servidor.
 * Llamar desde el layout raíz para monitoreo continuo.
 */
export function logWebVitals(metric: {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  id: string;
}) {
  const emoji = metric.rating === 'good' ? '✅' : metric.rating === 'needs-improvement' ? '⚠️' : '❌';
  console.log(
    `[WebVitals] ${emoji} ${metric.name}: ${Math.round(metric.value)}ms (${metric.rating})`
  );

  // En producción, enviar a tu servicio de analytics (ej. Vercel Analytics, PostHog)
  if (process.env.NODE_ENV === 'production') {
    // fetch('/api/vitals', { method: 'POST', body: JSON.stringify(metric) });
  }
}

// ─── Paginación ───────────────────────────────────────────────────────────────
/**
 * Calcula los metadatos de paginación para un listado.
 */
export function getPaginationMeta(
  total: number,
  page: number,
  limit: number
) {
  const totalPages = Math.ceil(total / limit);
  return {
    total,
    page,
    totalPages,
    hasNextPage: page < totalPages - 1,
    hasPrevPage: page > 0,
  };
}

// ─── Validación de entorno ────────────────────────────────────────────────────
/**
 * Verifica que todas las variables de entorno requeridas estén presentes.
 * Llamar en el inicio de la aplicación.
 */
export function validateEnv() {
  const required = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'REVALIDATION_SECRET',
  ];

  const missing = required.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(
      `[Config] Variables de entorno faltantes: ${missing.join(', ')}\n` +
      'Copia .env.example a .env.local y completa los valores.'
    );
  }
}
