/**
 * lib/cache.ts
 * Módulo de caché inteligente para consultas a Supabase.
 *
 * Estrategia:
 *  - unstable_cache de Next.js envuelve cada consulta con TTL configurable.
 *  - Las consultas se etiquetan (tags) para invalidación granular.
 *  - Cuando se publica/actualiza un artículo, solo se invalida su tag.
 *  - Los visitantes recurrentes NUNCA golpean la base de datos.
 *
 * TTL recomendados:
 *  - Listado de artículos: 1 hora (3600 s)
 *  - Artículo individual:  24 horas (86400 s), invalidado on-demand
 *  - Metadatos del sitio:  1 semana (604800 s)
 */

import { unstable_cache } from 'next/cache';
import { supabase } from './supabase';
import type { Article, ArticleListItem, ArticleSlug } from '@/types/article';

// ─── Tags de caché ────────────────────────────────────────────────────────────
export const CACHE_TAGS = {
  articles: 'articles',
  article: (slug: string) => `article-${slug}`,
  sitemap: 'sitemap',
} as const;

// ─── TTL de caché ─────────────────────────────────────────────────────────────
export const CACHE_TTL = {
  articleList: 3600,      // 1 hora
  articleDetail: 86400,   // 24 horas
  sitemap: 604800,        // 1 semana
} as const;

// ─── Función: Obtener listado de artículos (paginado) ─────────────────────────
/**
 * Devuelve una página de artículos publicados con solo los campos necesarios
 * para el listado (sin contenido completo). Resultado cacheado 1 hora.
 *
 * @param page   Número de página (base 0)
 * @param limit  Artículos por página (máx. 20 recomendado)
 */
export const getCachedArticleList = unstable_cache(
  async (page: number = 0, limit: number = 10): Promise<ArticleListItem[]> => {
    const start = Date.now();

    const from = page * limit;
    const to = from + limit - 1;

    const { data, error } = await supabase
      .from('articles')
      .select('id, slug, title, summary, published_at, cover_image_url, reading_time_minutes')
      .eq('status', 'published')
      .order('published_at', { ascending: false })
      .range(from, to);

    const elapsed = Date.now() - start;
    console.log(`[Cache] getCachedArticleList(page=${page}) → ${elapsed}ms | rows=${data?.length ?? 0}`);

    if (error) {
      console.error('[Cache] Error al obtener listado de artículos:', error.message);
      throw new Error(`Error al obtener artículos: ${error.message}`);
    }

    return data ?? [];
  },
  ['article-list'],
  {
    revalidate: CACHE_TTL.articleList,
    tags: [CACHE_TAGS.articles],
  }
);

// ─── Función: Obtener artículo individual por slug ────────────────────────────
/**
 * Devuelve el artículo completo para una URL dada.
 * Resultado cacheado 24 horas e invalidado on-demand al publicar/editar.
 *
 * @param slug  Slug único del artículo (ej. "como-funciona-tcp-ip")
 */
export const getCachedArticleBySlug = unstable_cache(
  async (slug: string): Promise<Article | null> => {
    const start = Date.now();

    const { data, error } = await supabase
      .from('articles')
      .select(`
        id,
        slug,
        title,
        content,
        summary,
        published_at,
        updated_at,
        cover_image_url,
        reading_time_minutes,
        author:authors (
          id,
          name,
          avatar_url
        ),
        tags:article_tags (
          tag:tags (id, name, slug)
        )
      `)
      .eq('slug', slug)
      .eq('status', 'published')
      .single();

    const elapsed = Date.now() - start;
    console.log(`[Cache] getCachedArticleBySlug("${slug}") → ${elapsed}ms`);

    if (error) {
      if (error.code === 'PGRST116') return null; // No encontrado
      console.error(`[Cache] Error al obtener artículo "${slug}":`, error.message);
      throw new Error(`Error al obtener artículo: ${error.message}`);
    }

    return data as Article;
  },
  // La clave de caché incluye el slug para que cada artículo tenga su propia entrada
  ['article-by-slug'],
  {
    revalidate: CACHE_TTL.articleDetail,
    tags: [CACHE_TAGS.articles], // Tag global para invalidar todos a la vez si es necesario
  }
);

// ─── Función: Obtener todos los slugs (para generateStaticParams) ─────────────
/**
 * Devuelve solo los slugs de todos los artículos publicados.
 * Se usa en generateStaticParams para pre-generar páginas en build time.
 */
export const getCachedAllSlugs = unstable_cache(
  async (): Promise<ArticleSlug[]> => {
    const { data, error } = await supabase
      .from('articles')
      .select('slug')
      .eq('status', 'published')
      .order('published_at', { ascending: false });

    if (error) {
      console.error('[Cache] Error al obtener slugs:', error.message);
      return [];
    }

    return data ?? [];
  },
  ['all-slugs'],
  {
    revalidate: CACHE_TTL.sitemap,
    tags: [CACHE_TAGS.sitemap, CACHE_TAGS.articles],
  }
);

// ─── Función: Obtener artículos relacionados ──────────────────────────────────
/**
 * Devuelve hasta 3 artículos relacionados por tags compartidos.
 * Excluye el artículo actual.
 */
export const getCachedRelatedArticles = unstable_cache(
  async (currentSlug: string, tagIds: string[]): Promise<ArticleListItem[]> => {
    if (!tagIds.length) return [];

    const { data, error } = await supabase
      .from('articles')
      .select(`
        id, slug, title, summary, published_at, cover_image_url,
        article_tags!inner (tag_id)
      `)
      .eq('status', 'published')
      .neq('slug', currentSlug)
      .in('article_tags.tag_id', tagIds)
      .limit(3);

    if (error) return [];
    return (data ?? []) as ArticleListItem[];
  },
  ['related-articles'],
  {
    revalidate: CACHE_TTL.articleList,
    tags: [CACHE_TAGS.articles],
  }
);
